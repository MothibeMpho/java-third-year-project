/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stationarymanagementprg;
import Interfaces.LoginFrm;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import BusinesssLogic.DatabaseConnection;
import BusinesssLogic.ThreadClass;
import ClassObjects.Stock;
/**
 *
 * @author Mpho Mothibe
 */
public class StationaryManagementPRG
{
       static Connection con = DatabaseConnection.getInstance().getConnection();
       static PreparedStatement ps = null;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        ThreadClass tclass = new ThreadClass();
        
        Thread t1 = new Thread(tclass);
        t1.start();
          
    }
    
     public static List<Stock> selectAllStock() {
        List<Stock> list = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT * FROM `stock`");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Stock stock = new Stock(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
                list.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }
    
}
