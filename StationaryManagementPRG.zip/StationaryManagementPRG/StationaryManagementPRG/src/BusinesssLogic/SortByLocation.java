/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import java.util.Comparator;
import ClassObjects.Staff;

/**
 *
 * @author Mpho Mothibe
 */
public class SortByLocation implements Comparator<Staff>
{

    @Override
    public int compare(Staff o1, Staff o2) {
        return o1.getLocation().compareTo(o2.getLocation());
    }
    
}
