/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import ClassObjects.Staff;
import ClassObjects.User;

/**
 *
 * @author Mpho Mothibe
 */
public class UserLogic 
{
       public static int CURRENT_USERID;
       PreparedStatement ps;
       static Connection con = DatabaseConnection.getInstance().getConnection();
       ResultSet rs;

    public boolean userLogin(User user) {
        boolean state = false;
        try {
            ps = con.prepareStatement("SELECT * FROM `user` WHERE username=? and password=?");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            rs = ps.executeQuery();
            while (rs.next()) {
                state = true;
                CURRENT_USERID = user.getId();
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;

    }
    
    public boolean userRegistration(User user,Staff staff)
    {
        boolean state = false;
        try
        {
            String query = "INSERT INTO `staff`(`staffID`, `Name`, `Surname`, `cellNr`, `email`, `department`, `location`) VALUES (null,?,?,?,?,?,?)";
            ps = con.prepareStatement(query);
            ps.setString(1, staff.getName());
            ps.setString(2, staff.getSname());
            ps.setString(3, staff.getCellnr());
            ps.setString(4, staff.getEmail());
            ps.setString(5, staff.getDepartment());
            ps.setString(6, staff.getLocation());
            int s = ps.executeUpdate();
            
            if (s == 1)
            {
                query = "INSERT INTO `user`(`userID`, `username`, `password`) VALUES (null,?,?)";
                ps = con.prepareStatement(query);
                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPassword());
                int s2 = ps.executeUpdate();
                
                if (s2 == 1)
                {
                    System.out.println("Successful registration");
                    state = true;
                }
                else
                {
                    System.out.println("Registration Failed");
                    state = false;
                }
            }
            
            
            
        }
        catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
        
        return state;
    }
    
    
}
