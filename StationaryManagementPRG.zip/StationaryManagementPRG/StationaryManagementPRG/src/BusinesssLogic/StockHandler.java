/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ClassObjects.Stock;

/**
 *
 * @author Mpho Mothibe
 */
public class StockHandler
{
    static Connection con = DatabaseConnection.getInstance().getConnection();
    static PreparedStatement ps = null;

    //select 

    /**
     *
     * @return
     */
    public static List<Stock> selectAllStock() {
        List<Stock> list = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT * FROM `stock`");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Stock stock = new Stock(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
                list.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }
    
    public static List<Stock> selectNameStock(String type)
    {
        List<Stock> list = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT `stockID`, `DateEntry`, `Quantitity`, `type` FROM `stock` WHERE`type`=?");
            ps.setString(1, type);
            ResultSet rs = ps.executeQuery();
            while (rs.next())
            {
                Stock stock = new Stock(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
                list.add(stock);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }

    //delete
    public static boolean deleteStock(Stock stock)
    {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `stock` WHERE stock.stockID =?");
            ps.setInt(1, stock.getId());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    /**
     *
     * @param stock
     * @return
     */
    public static boolean insertStock(Stock stock) 
    {
        
        boolean state = false;
        try {
            ps = con.prepareStatement("INSERT INTO `stock`(`DateEntry`, `Quantitity`, `type`) VALUES (?,?,?) ");
          
            ps.setString(1,stock.getDate());
            ps.setInt(2,stock.getQuantity());
            ps.setString(3,stock.getType());
            if (ps.executeUpdate() > 0) 
            {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
    public static boolean UpdateStock(Stock stock) 
    {
        boolean state = false;
        try {
            ps = con.prepareStatement("UPDATE `stock` SET `DateEntry`=?,`Quantitity`=?,`type`=? WHERE `stockID`=? ");
          
            ps.setString(1,stock.getDate());
            ps.setInt(2,stock.getQuantity());
            ps.setString(3,stock.getType());
            ps.setInt(4, stock.getId());
            if (ps.executeUpdate() > 0) 
            {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
    
}
