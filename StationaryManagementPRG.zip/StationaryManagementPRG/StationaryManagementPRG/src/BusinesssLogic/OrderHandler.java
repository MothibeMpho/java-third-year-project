/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ClassObjects.Order;
import java.sql.Connection;

/**
 *
 * @author Mpho Mothibe
 */
public class OrderHandler
{
    static Connection con = DatabaseConnection.getInstance().getConnection();
    static PreparedStatement ps;
    
    /**
     *
     * @param order
     * @return
     */
    public static boolean OrderRequest(Order order)
    {
        boolean state = false;
        String query = "INSERT INTO `stockorders` (`OrderType`, `orderDate`, `orderQuantity`, `expectedDate`) VALUES (?, ?, ?, ?)";
        try 
        {
            ps = con.prepareStatement(query);
            ps.setString(1, order.getType());
            ps.setString(2, order.getOrderdate());
            ps.setInt(3, order.getQuantity());
            ps.setString(4, order.getExpecteddate());
            
            if (1 <= ps.executeUpdate())
            {
                state = true;
            }
        } 
        catch (SQLException ex)
        {
            System.out.println(ex.getMessage());
        }
        
        return state;
    }
    
    public static List<Order> SelectOrders()
    {
        List<Order> list = new ArrayList();
        
        try 
        {
            ps = con.prepareStatement("SELECT `orderID`,`OrderType`,`orderQuantity`,`orderDate`,`expectedDate` FROM `stockorders`");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next())
            {                
                Order order = new Order(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5));
                list.add(order);
            }
        } catch (SQLException e)
        {
            System.out.println(e.getMessage());
        }
        
        return list;
    }
    
      public static boolean deleteOrder(Order order)
    {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `stockorders` WHERE orderID =?");
            ps.setInt(1, order.getId());
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }
    
}
