/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ClassObjects.Staff;

/**
 *
 * @author Mpho Mothibe
 */
public class StaffHandler 
{
  static Connection con = DatabaseConnection.getInstance().getConnection();
    static PreparedStatement ps = null;

    //select 

    /**
     *
     * @return
     */
    public static List<Staff> selectAllStock() {
        List<Staff> list = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT * FROM `staff`");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Staff staff = new Staff(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(5), rs.getString(4), rs.getString(6), rs.getString(7));
                list.add(staff);
            }
        } 
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }
    
    public static List<Staff> selectNameStock(String name)
    {
        List<Staff> list = new ArrayList();
        try {
            ps = con.prepareStatement("SELECT * FROM `staff` WHERE `Name` = ?");
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Staff staff = new Staff(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
                list.add(staff);
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return list;
    }

    //delete
    public static boolean deleteStaff(int id)
    {
        boolean state = false;
        try {
            ps = con.prepareStatement("DELETE FROM `staff` WHERE staff.staffID =?");
            ps.setInt(1, id);
            if (ps.executeUpdate() > 0) {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return state;
    }

    /**
     *
     * @param staff
     * @return
     */
    public  boolean insertStaff(Staff staff) 
    {
        boolean state = false;
        try {
            String query = "INSERT INTO `staff`(`staffID`, `Name`, `Surname`, `cellNr`, `email`, `department`, `location`) VALUES (null,?,?,?,?,?,?)";
            ps = con.prepareStatement(query);
            ps.setString(1, staff.getName());
            ps.setString(2, staff.getSname());
            ps.setString(3, staff.getCellnr());
            ps.setString(4, staff.getEmail());
            ps.setString(5, staff.getDepartment());
            ps.setString(6, staff.getLocation());
            if (ps.executeUpdate() > 0) 
            {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
    public static boolean UpdateStock(Staff staff) 
    {
        boolean state = false;
        try {
            ps = con.prepareStatement("UPDATE `staff` SET `Name`=?,`Surname`=?,`cellNr`=?, `email`=?, `department`=?, `location`=? WHERE `staffID`=? ");
          
            ps.setString(1, staff.getName());
            ps.setString(2, staff.getSname());
            ps.setString(3, staff.getCellnr());
            ps.setString(4, staff.getEmail());
            ps.setString(5, staff.getDepartment());
            ps.setString(6, staff.getLocation());
            ps.setInt(7, staff.getId());
            if (ps.executeUpdate() > 0) 
            {
                state = true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return state;
    }
}
