/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import ClassObjects.Staff;


/**
 *
 * @author Mpho Mothibe
 */
public class StaffTableModel extends AbstractTableModel
{

    List<Staff> staff = new ArrayList();

    public StaffTableModel()
    {
    }
    
    public List<Staff> SortByLocation()
    {
        Collections.sort(this.staff,new SortByLocation());
        return staff;
    }
    
    public void deleteStaff(Staff staf)
    {
        this.staff.remove(staf);
        fireTableDataChanged();
    }

    @Override
    public int getRowCount() {
        return this.staff.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex)
    {
        Staff list = getStaff(rowIndex);
        switch (columnIndex) {
            case 0:
                return list.getId();
            case 1:
                return list.getName();
            case 2:
                return list.getSname();
            case 3:
                return list.getLocation();
            case 4:
                return list.getCellnr();
            case 5:
                return list.getDepartment();
            case 6:
                return list.getEmail();
            default:
                return null;
        }

    }

     @Override
    public String getColumnName(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return "Staff ID";
            case 1:
                return "Name";
            case 2:
                return "Surname";
            case 3:
                return "Campus Location";
            case 4:
                return "Contact Number";
            case 5:
                return "Department";
            case 6:
                return "Email";
            default:
                return null;
        }
    }
    
    public void insertStaff(Staff staff)
    {
        this.staff.add(staff);
        fireTableDataChanged();
    }

    public StaffTableModel(List<Staff> staff) 
    {
        this.staff = staff;
    }
    
    public Staff getStaff(int index) {
        return this.staff.get(index);
    }
    
    
}