/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import Interfaces.LoginFrm;
import Server.ServerClass;

/**
 *
 * @author Student5
 */
public class ThreadClass implements Runnable
{

    @Override
    public void run() {
      LoginFrm form = new LoginFrm();
        form.setVisible(true);
        form.setLocationRelativeTo(null);
        
        
    }
    
}
