/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import ClassObjects.Order;
import ClassObjects.Stock;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Mpho Mothibe
 */
public class OrderTableModel extends AbstractTableModel
{

    List<Order> list = new ArrayList();

    public OrderTableModel(List<Order> list) {
        this.list = list;
    }

    public void deleteOrder(Order order) {
        this.list.remove(order);
        fireTableDataChanged();
    }

    public void insertOrder(Order order) {
        this.list.add(order);
        fireTableDataChanged();
    }
   
    

    public Order getOrder(int index) {
        return this.list.get(index);
    }

    @Override
    public int getRowCount() {
        return this.list.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) 
    {
        Order o = getOrder(rowIndex);
        switch (columnIndex) {
            case 0:
                return o.getId();
            case 1:
                return o.getType();
            case 2:
                return o.getQuantity();
            case 3:
                return o.getOrderdate();
            case 4:
                return o.getExpecteddate();
            default:
                return null;
        }    
    }
    
      @Override
    public String getColumnName(int columnIndex) {
       switch (columnIndex) {
            case 0:
                return "Order ID";
            case 1:
                return "Order Type";
            case 2:
                return "Quantity";
            case 3:
                return "Order Date";
            case 4:
                return "Expected Date";
            default:
                return null;
        }
    }
}
