/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import ClassObjects.Stock;
import java.util.Collections;

/**
 *
 * @author Mpho Mothibe
 */
public class StockTableModel extends AbstractTableModel {

    List<Stock> list = new ArrayList();

    public StockTableModel(List<Stock> list) {
        this.list = list;
    }

    public void deleteStock(Stock stock) {
        this.list.remove(stock);
        fireTableDataChanged();
    }
  
      public List<Stock> SortByCategory()
    {
        Collections.sort(list, new SortByCategory());
        return list;
    }
    public void insertStock(Stock stock) {
        this.list.add(stock);
        fireTableDataChanged();
    }
   
    

    public Stock getStock(int index) {
        return this.list.get(index);
    }

    @Override
    public int getRowCount() {
        return this.list.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Stock s = getStock(rowIndex);
        switch (columnIndex) {
            case 0:
                return s.getId();
            case 1:
                return s.getType();
            case 2:
                return s.getQuantity();
            case 3:
                return s.getDate();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columnIndex) {
       switch (columnIndex) {
            case 0:
                return "Stock ID";
            case 1:
                return "Stock Type";
            case 2:
                return "Quantity";
            case 3:
                return "Entry Date";
            default:
                return null;
        }
    }
}
