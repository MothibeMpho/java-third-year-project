/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BusinesssLogic;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Mpho Mothibe
 */
public class DatabaseConnection
{
     public Connection getConnection() {
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/campusstationary?";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, "root", "");
            if (con != null)
            {
                System.out.println("db connection open!!!");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Connection failed");
        }
        return con;
    }
    
     private static DatabaseConnection jdbc;
     
     public static DatabaseConnection getInstance()
     {
         if (jdbc == null)
         {
             jdbc = new DatabaseConnection();
         }
         return jdbc;
     }
}
