/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;
import BusinesssLogic.DatabaseConnection;
import ClassObjects.Order;
import RMIInterface.RMIInterface;
import com.mysql.jdbc.Connection;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Mpho Mothibe
 */
public class ServerClass extends UnicastRemoteObject  implements RMIInterface
{

    public ServerClass() throws RemoteException 
    {
        super();
    }
    
    public static void main(String args[]) throws RemoteException
    {
      
        Registry reg = LocateRegistry.createRegistry(1050);
        reg.rebind("SQRTServer", new ServerClass());
        System.out.println("Server ready....");

    }
    

    @Override
    public List<Order> SelectAll() throws RemoteException
    {
        List<Order> list = new ArrayList();

        try
        {
            
            Connection con = (Connection) DatabaseConnection.getInstance().getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM stockorders");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next())
            {                
                Order order = new Order(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
                list.add(order);
            }
        } 
        catch (SQLException ex)
        {
            System.out.println(ex.getMessage());
        }
        return list;
    }
    
}
