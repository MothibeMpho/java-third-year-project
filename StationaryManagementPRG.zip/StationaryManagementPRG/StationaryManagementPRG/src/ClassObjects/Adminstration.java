/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassObjects;

/**
 *
 * @author Mpho Mothibe
 */
public class Adminstration 
{
    private int id;
    private String name;
    private String sname;
    private String email;
    private String cellnr;

    public Adminstration(int id, String name, String sname, String email, String cellnr) {
        this.id = id;
        this.name = name;
        this.sname = sname;
        this.email = email;
        this.cellnr = cellnr;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCellnr() {
        return cellnr;
    }

    public void setCellnr(String cellnr) {
        this.cellnr = cellnr;
    }

   
    
}
