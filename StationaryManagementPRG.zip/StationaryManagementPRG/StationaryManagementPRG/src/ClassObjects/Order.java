/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassObjects;

import java.io.Serializable;



/**
 *
 * @author Mpho Mothibe
 */
public class Order implements Serializable
{
    private int id,quantity;
    private String type,orderdate,expecteddate;

    public Order(int id) {
        this.id = id;
    }
    

    public Order(int quantity, String type, String orderdate, String expecteddate) {
        this.quantity = quantity;
        this.type = type;
        this.orderdate = orderdate;
        this.expecteddate = expecteddate;
    }

    public Order(int id, String type, int quantity ,String orderdate, String expecteddate) {
        this.id = id;
        this.quantity = quantity;
        this.type = type;
        this.orderdate = orderdate;
        this.expecteddate = expecteddate;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String orderdate) {
        this.orderdate = orderdate;
    }

    public String getExpecteddate() {
        return expecteddate;
    }

    public void setExpecteddate(String expecteddate) {
        this.expecteddate = expecteddate;
    }
}
