/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassObjects;

/**
 *
 * @author Mpho Mothibe
 */
public class Stock
{
    private int id;
    private String date;
    private int quantity;
    private String type;

    public Stock(int id,String date, int quantity,String type)
    {
        this.id = id;
        this.type = type;
        this.date = date;
        this.quantity = quantity;
    }
    public Stock(String type,String date, int quantity) {
        
        this.type = type;
        this.date = date;
        this.quantity = quantity;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Stock(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
