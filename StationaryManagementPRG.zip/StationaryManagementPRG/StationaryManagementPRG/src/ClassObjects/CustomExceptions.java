/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassObjects;
import java.lang.Exception;


/**
 *
 * @author Mpho Mothibe
 */
public class CustomExceptions extends Exception
{

    public CustomExceptions(String message) {
        super(message);
    }

    public CustomExceptions() {
    }

    public CustomExceptions(String message, Throwable cause) {
        super(message, cause);
    }

    public CustomExceptions(Throwable cause) {
        super(cause);
    }

    public CustomExceptions(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    

    
}
