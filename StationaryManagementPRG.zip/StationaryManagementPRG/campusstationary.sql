-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 31, 2018 at 09:56 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `campusstationary`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `sp_Register`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_Register` (IN `uname` VARCHAR(50), IN `pword` VARCHAR(50), IN `fname` VARCHAR(35), IN `sname` VARCHAR(35), IN `cell` VARCHAR(10), IN `email` VARCHAR(50))  MODIFIES SQL DATA
BEGIN
insert into `campusstationary`.`user`(`username`,`password`) values(uname,pword);
INSERT INTO `campusstationary`.`staff`(`Name`,`Surname`,`cellNr`,`email`)
values (fname,sname,cell,email);
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `adminID` int(11) NOT NULL,
  `name` varchar(35) NOT NULL,
  `surname` varchar(35) NOT NULL,
  `cellnr` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `userID(FK)` int(11) NOT NULL,
  `LocID(FK)` int(11) NOT NULL,
  PRIMARY KEY (`adminID`),
  UNIQUE KEY `uID` (`userID(FK)`),
  UNIQUE KEY `locID` (`LocID(FK)`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE IF NOT EXISTS `staff` (
  `staffID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text NOT NULL,
  `Surname` text NOT NULL,
  `cellNr` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `department` varchar(85) NOT NULL,
  `location` varchar(85) NOT NULL,
  PRIMARY KEY (`staffID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `Name`, `Surname`, `cellNr`, `email`, `department`, `location`) VALUES
(2, 'Kelebogile', 'Hopolang', '0123456789', 'test@test.com', 'HR', 'Johannesburg'),
(3, 'Mpho', 'Mothibe', '0123456789', 'test@test', 'lecturer', 'Port Elizabeth');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `stockID` int(11) NOT NULL AUTO_INCREMENT,
  `DateEntry` date NOT NULL,
  `Quantitity` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`stockID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`stockID`, `DateEntry`, `Quantitity`, `type`) VALUES
(1, '2018-10-02', 5, 'pen'),
(2, '2018-10-15', 10, 'pencils'),
(3, '2018-10-30', 10, 'scissors'),
(4, '2018-10-30', 10, 'Eraser'),
(5, '2018-10-30', 50, 'Stapler'),
(6, '2018-10-30', 50, 'Stapler');

-- --------------------------------------------------------

--
-- Table structure for table `stockorders`
--

DROP TABLE IF EXISTS `stockorders`;
CREATE TABLE IF NOT EXISTS `stockorders` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `OrderType` varchar(50) NOT NULL,
  `orderDate` date NOT NULL,
  `orderQuantity` int(11) NOT NULL,
  `expectedDate` date NOT NULL,
  PRIMARY KEY (`orderID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stockorders`
--

INSERT INTO `stockorders` (`orderID`, `OrderType`, `orderDate`, `orderQuantity`, `expectedDate`) VALUES
(1, 'pencil', '2018-10-30', 15, '2018-11-15'),
(2, 'pencil', '2018-10-30', 5, '2018-11-06'),
(3, 'test', '2018-10-11', 1, '2018-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `username`, `password`) VALUES
(1, '123', '123'),
(2, 'test ', '123'),
(3, 'test', 'test'),
(4, 'test', 'test'),
(5, 'test', 'test'),
(6, 'test', 'test'),
(7, 'kele', 'hopo');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `userID(FK)` FOREIGN KEY (`userID(FK)`) REFERENCES `user` (`userID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
